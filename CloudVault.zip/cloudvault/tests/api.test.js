'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createServer } = require('../server');

let server, base, dir, port;

function listen(srv) {
  return new Promise((resolve) => srv.listen(0, '127.0.0.1', () => resolve(srv.address().port)));
}

before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cloudvault-test-'));
  server = createServer({ STORAGE_DIR: dir, MAX_UPLOAD_BYTES: 1024, HOST: '127.0.0.1' });
  await server.storage.ready;
  port = await listen(server);
  base = `http://127.0.0.1:${port}`;
});

after(() => {
  server.close();
  fs.rmSync(dir, { recursive: true, force: true });
});

const put = (name, body, headers = {}) =>
  fetch(`${base}/api/files/${encodeURIComponent(name)}`, { method: 'PUT', body, headers });
const getText = async (url) => {
  const res = await fetch(url);
  return { res, text: await res.text() };
};

/** Raw request, for things fetch() refuses to do (custom Origin, unnormalised paths, chunked bodies). */
function raw({ method = 'GET', path: p, headers = {}, body }) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, method, path: p, headers }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString() }));
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

test('health and config endpoints respond', async () => {
  const health = await (await fetch(`${base}/api/health`)).json();
  assert.equal(health.status, 'ok');
  const cfg = await (await fetch(`${base}/api/config`)).json();
  assert.equal(cfg.maxUploadBytes, 1024);
});

test('the web page and its assets are served with security headers', async () => {
  for (const asset of ['/', '/app.js', '/styles.css']) {
    const res = await fetch(base + asset);
    assert.equal(res.status, 200, asset);
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    assert.match(res.headers.get('content-security-policy'), /default-src 'self'/);
    await res.arrayBuffer();
  }
});

test('first upload creates version 1', async () => {
  const res = await put('notes.txt', 'first draft', { 'X-Version-Note': encodeURIComponent('Initial draft') });
  assert.equal(res.status, 201);
  const body = await res.json();
  assert.equal(body.version.version, 1);
  assert.equal(body.version.note, 'Initial draft');
  assert.equal(body.file.versionCount, 1);
});

test('re-uploading identical content does not create a new version', async () => {
  const res = await put('notes.txt', 'first draft');
  assert.equal(res.status, 200);
  assert.equal((await res.json()).created, false);
});

test('changed content creates version 2 and history lists newest first', async () => {
  const res = await put('notes.txt', 'second draft, longer');
  assert.equal(res.status, 201);
  assert.equal((await res.json()).version.version, 2);

  const history = await (await fetch(`${base}/api/files/notes.txt/versions`)).json();
  assert.equal(history.currentVersion, 2);
  assert.deepEqual(history.versions.map((v) => v.version), [2, 1]);
  assert.equal(history.versions[0].isCurrent, true);
  assert.equal(history.versions[1].isCurrent, false);
});

test('file listing reports totals', async () => {
  const data = await (await fetch(`${base}/api/files`)).json();
  assert.equal(data.files.length, 1);
  assert.equal(data.files[0].name, 'notes.txt');
  assert.equal(data.files[0].currentVersion, 2);
  assert.equal(data.totals.versions, 2);
  assert.equal(data.totals.bytes, 'first draft'.length + 'second draft, longer'.length);
});

test('download returns current or a chosen version as an attachment', async () => {
  const current = await getText(`${base}/api/files/notes.txt`);
  assert.equal(current.text, 'second draft, longer');
  assert.match(current.res.headers.get('content-disposition'), /^attachment; filename="notes\.txt"/);
  assert.equal(current.res.headers.get('content-type'), 'application/octet-stream');
  assert.equal(current.res.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(current.res.headers.get('x-cloudvault-version'), '2');

  const old = await getText(`${base}/api/files/notes.txt?version=1`);
  assert.equal(old.text, 'first draft');
  assert.match(old.res.headers.get('content-disposition'), /notes \(v1\)\.txt/);
});

test('restoring an old version creates a new version and keeps history', async () => {
  const res = await fetch(`${base}/api/files/notes.txt/restore`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ version: 1 }),
  });
  assert.equal(res.status, 201);
  const body = await res.json();
  assert.equal(body.version.version, 3);
  assert.equal(body.version.restoredFrom, 1);

  assert.equal((await getText(`${base}/api/files/notes.txt`)).text, 'first draft');
  assert.equal((await getText(`${base}/api/files/notes.txt?version=2`)).text, 'second draft, longer');
});

test('restore rejects identical, missing and malformed versions', async () => {
  const restore = (version) => fetch(`${base}/api/files/notes.txt/restore`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ version }),
  });
  assert.equal((await restore(3)).status, 409); // current
  assert.equal((await restore(1)).status, 409); // same bytes as current
  assert.equal((await restore(99)).status, 404);
  assert.equal((await restore('abc')).status, 400);
  assert.equal((await restore(-1)).status, 400);
  const missing = await fetch(`${base}/api/files/nothing.txt/restore`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ version: 1 }),
  });
  assert.equal(missing.status, 404);
});

test('unsafe file names are rejected', async () => {
  const bad = [
    '../secret.txt', '..\\secret.txt', 'a/b.txt', 'bad?.txt', 'con.txt', 'NUL', '.hidden',
    'trailing.', ' leading.txt', 'virus.exe', 'x'.repeat(121), 'two..dots.txt', 'pipe|name.txt',
  ];
  for (const name of bad) {
    const res = await put(name, 'x');
    assert.equal(res.status, 400, `expected 400 for ${JSON.stringify(name)}`);
    await res.arrayBuffer();
  }
  assert.equal((await raw({ path: '/api/files/%2e%2e%2fsecret' })).status, 400);
  assert.equal((await raw({ path: '/api/files/%E0%A4%A' })).status, 400); // malformed escape
});

test('unicode and spaces in names work, including the download header', async () => {
  const name = 'résumé final.txt';
  assert.equal((await put(name, 'hello')).status, 201);
  const { res, text } = await getText(`${base}/api/files/${encodeURIComponent(name)}`);
  assert.equal(text, 'hello');
  assert.match(res.headers.get('content-disposition'), /filename\*=UTF-8''r%C3%A9sum%C3%A9%20final\.txt/);
});

test('path traversal against the static server is blocked', async () => {
  for (const p of ['/..%2fserver.js', '/%2e%2e/server.js', '/..%2f..%2fetc%2fpasswd']) {
    const r = await raw({ path: p });
    assert.ok([400, 403, 404].includes(r.status), `${p} returned ${r.status}`);
    assert.ok(!r.body.includes('createServer'));
  }
});

test('uploads over the size limit are rejected (declared and streamed)', async () => {
  const declared = await put('big.bin', Buffer.alloc(2000, 1));
  assert.equal(declared.status, 413);
  await declared.arrayBuffer();

  const chunked = await raw({ method: 'PUT', path: '/api/files/big2.bin', body: Buffer.alloc(2000, 1) });
  // raw() sends a Content-Length, so also exercise the no-length path:
  assert.equal(chunked.status, 413);
  const streamed = await new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, method: 'PUT', path: '/api/files/big3.bin', headers: { 'Transfer-Encoding': 'chunked' } },
      (res) => { res.resume(); res.on('end', () => resolve(res.statusCode)); });
    req.on('error', reject);
    req.write(Buffer.alloc(700, 1));
    req.write(Buffer.alloc(700, 1));
    req.end();
  });
  assert.equal(streamed, 413);
  assert.equal((await fetch(`${base}/api/files/big3.bin`)).status, 404); // nothing half-saved
  assert.deepEqual(fs.readdirSync(path.join(dir, 'tmp')), []);
});

test('cross-origin writes and foreign Host headers are refused', async () => {
  const crossSite = await raw({ method: 'PUT', path: '/api/files/evil.txt', headers: { Origin: 'http://evil.example' }, body: 'x' });
  assert.equal(crossSite.status, 403);
  const rebinding = await raw({ path: '/api/files', headers: { Host: 'evil.example' } });
  assert.equal(rebinding.status, 403);
  const sameSite = await raw({ method: 'PUT', path: '/api/files/ok.txt', headers: { Origin: base }, body: 'x' });
  assert.equal(sameSite.status, 201);
});

test('unknown routes and wrong methods return JSON errors', async () => {
  assert.equal((await fetch(`${base}/api/nope`)).status, 404);
  assert.equal((await fetch(`${base}/api/files`, { method: 'DELETE' })).status, 405);
  assert.equal((await fetch(`${base}/api/files/ok.txt`, { method: 'DELETE' })).status, 405);
  assert.equal((await fetch(`${base}/missing.html`)).status, 404);
  assert.equal((await fetch(`${base}/api/files/ok.txt?version=zero`)).status, 400);
});

test('concurrent uploads of one file get unique, gapless version numbers', async () => {
  const results = await Promise.all(
    Array.from({ length: 6 }, (_, i) => put('race.txt', `content ${i}`).then((r) => r.json()))
  );
  const versions = results.map((r) => r.version.version).sort((a, b) => a - b);
  assert.deepEqual(versions, [1, 2, 3, 4, 5, 6]);
});

test('a tampered stored version is detected and refused on restore', async () => {
  await put('fragile.txt', 'original');
  await put('fragile.txt', 'edited');
  const key = server.storage.keyFor('fragile.txt');
  fs.writeFileSync(path.join(dir, 'objects', key, 'v1.bin'), 'corrupted!');
  const res = await fetch(`${base}/api/files/fragile.txt/restore`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ version: 1 }),
  });
  assert.equal(res.status, 409);
  assert.match((await res.json()).error, /Integrity check failed/);
});

test('oldest versions are pruned beyond the limit but the current one is kept', async () => {
  const small = createServer({ STORAGE_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'cv-prune-')), MAX_VERSIONS: 3, HOST: '127.0.0.1' });
  await small.storage.ready;
  const p = await listen(small);
  for (let i = 1; i <= 5; i += 1) {
    await fetch(`http://127.0.0.1:${p}/api/files/log.txt`, { method: 'PUT', body: `rev ${i}` });
  }
  const history = await (await fetch(`http://127.0.0.1:${p}/api/files/log.txt/versions`)).json();
  assert.deepEqual(history.versions.map((v) => v.version), [5, 4, 3]);
  assert.equal(fs.existsSync(path.join(small.storage.dirFor('log.txt'), 'v1.bin')), false);
  small.close();
});

test('data survives a server restart', async () => {
  const second = createServer({ STORAGE_DIR: dir, MAX_UPLOAD_BYTES: 1024, HOST: '127.0.0.1' });
  await second.storage.ready;
  const p = await listen(second);
  const data = await (await fetch(`http://127.0.0.1:${p}/api/files`)).json();
  assert.ok(data.files.some((f) => f.name === 'notes.txt' && f.currentVersion === 3));
  second.close();
});
