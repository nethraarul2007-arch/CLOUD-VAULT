'use strict';
(() => {
  const $ = (selector) => document.querySelector(selector);

  const state = {
    files: [],
    selected: null,
    filter: '',
    maxUploadBytes: 50 * 1024 * 1024,
    pendingRestore: null,
  };

  /* ---------- helpers ---------- */

  // Builds DOM with textContent only, so file names can never inject HTML.
  function el(tag, props = {}, ...children) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props)) {
      if (key === 'class') node.className = value;
      else if (key === 'text') node.textContent = value;
      else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
      else if (value !== false && value != null) node.setAttribute(key, value === true ? '' : value);
    }
    for (const child of children.flat()) if (child != null) node.append(child);
    return node;
  }

  const fileUrl = (name, suffix = '') => `/api/files/${encodeURIComponent(name)}${suffix}`;

  function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    const units = ['KB', 'MB', 'GB'];
    let value = bytes / 1024;
    let i = 0;
    while (value >= 1024 && i < units.length - 1) { value /= 1024; i += 1; }
    return `${value.toFixed(value < 10 ? 1 : 0)} ${units[i]}`;
  }

  function formatDate(iso) {
    return new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  }

  function toast(message, isError = false) {
    const node = el('div', { class: `toast${isError ? ' error' : ''}`, text: message });
    $('#toasts').append(node);
    setTimeout(() => node.remove(), isError ? 8000 : 4500);
  }

  async function api(url, options) {
    const response = await fetch(url, options);
    let body = {};
    try { body = await response.json(); } catch { /* non-JSON response */ }
    if (!response.ok) throw new Error(body.error || `Request failed (${response.status}).`);
    return body;
  }

  /* Mirrors lib/validate.js so mistakes are caught before uploading.
     The server re-checks everything; this is only for faster feedback. */
  const FORBIDDEN = /[\\/:*?"<>|\u0000-\u001f\u007f]/;
  const RESERVED = /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i;
  const BLOCKED_EXT = /\.(exe|bat|cmd|com|scr|msi|dll|vbs|ps1)$/i;
  function checkName(name) {
    if (!name || name !== name.trim()) return 'File names cannot be empty or start/end with a space.';
    if (name.length > 120) return 'File names are limited to 120 characters.';
    if (FORBIDDEN.test(name)) return 'File names cannot contain \\ / : * ? " < > | or control characters.';
    if (name.startsWith('.') || name.endsWith('.') || name.includes('..')) return 'File names cannot start or end with a dot or contain "..".';
    if (RESERVED.test(name.split('.')[0])) return `"${name.split('.')[0]}" is a reserved system name.`;
    if (BLOCKED_EXT.test(name)) return 'This file type is not accepted.';
    return null;
  }

  /* ---------- file list ---------- */

  async function refresh() {
    const data = await api('/api/files');
    state.files = data.files;
    $('#totalFiles').textContent = data.totals.files;
    $('#totalVersions').textContent = data.totals.versions;
    $('#totalBytes').textContent = formatBytes(data.totals.bytes);
    renderFiles();
    if (state.selected && !state.files.some((f) => f.name === state.selected)) state.selected = null;
    await renderHistory();
  }

  function renderFiles() {
    const rows = $('#fileRows');
    rows.replaceChildren();
    const needle = state.filter.toLowerCase();
    const visible = state.files.filter((f) => f.name.toLowerCase().includes(needle));
    $('#emptyState').hidden = visible.length > 0;
    $('#emptyState').textContent = state.files.length
      ? 'No files match that filter.'
      : 'No files yet. Drop a file above to store its first version.';

    for (const file of visible) {
      const row = el('tr', { class: `file-row${file.name === state.selected ? ' selected' : ''}` },
        el('td', {}, el('button', {
          type: 'button', class: 'file-name link-btn', text: file.name,
          'aria-pressed': String(file.name === state.selected),
          onclick: (e) => { e.stopPropagation(); select(file.name); },
        })),
        el('td', {}, el('span', { class: 'vbadge', text: `v${file.currentVersion}` })),
        el('td', { class: 'muted', text: formatBytes(file.size) }),
        el('td', { class: 'muted', text: formatDate(file.updatedAt) }),
        el('td', {}, el('div', { class: 'actions' },
          el('a', { class: 'btn', href: fileUrl(file.name), text: 'Download', onclick: (e) => e.stopPropagation() }),
          el('button', { type: 'button', class: 'btn', text: 'History', onclick: (e) => { e.stopPropagation(); select(file.name); } }),
        )),
      );
      row.addEventListener('click', () => select(file.name));
      rows.append(row);
    }
  }

  async function select(name) {
    state.selected = name;
    renderFiles();
    await renderHistory();
  }

  /* ---------- version history ---------- */

  async function renderHistory() {
    const empty = $('#historyEmpty');
    const body = $('#historyBody');
    if (!state.selected) { empty.hidden = false; body.hidden = true; return; }
    let history;
    try {
      history = await api(fileUrl(state.selected, '/versions'));
    } catch (err) {
      toast(err.message, true);
      return;
    }
    empty.hidden = true;
    body.hidden = false;
    $('#historyFile').textContent = `${history.name} · ${history.versions.length} version${history.versions.length === 1 ? '' : 's'} kept`;

    const list = $('#timeline');
    list.replaceChildren();
    for (const v of history.versions) {
      const head = el('div', { class: 'tl-head' },
        el('span', { class: 'tl-version', text: `Version ${v.version}` }),
        v.isCurrent ? el('span', { class: 'tl-tag', text: 'Current' }) : null,
      );
      const actions = el('div', { class: 'tl-actions' },
        el('a', { class: 'btn', href: fileUrl(history.name, `?version=${v.version}`), text: 'Download' }),
        v.isCurrent ? null : el('button', {
          type: 'button', class: 'btn primary', text: 'Restore',
          onclick: () => askRestore(history.name, v, history.currentVersion),
        }),
      );
      list.append(el('li', { class: `tl-item${v.isCurrent ? ' current' : ''}` },
        head,
        el('div', { class: 'tl-meta', text: `${formatDate(v.uploadedAt)} · ${formatBytes(v.size)}` }),
        v.note ? el('p', { class: 'tl-note', text: v.note }) : null,
        el('div', { class: 'tl-hash', text: `SHA-256 ${v.sha256.slice(0, 12)}…` }),
        actions,
      ));
    }
  }

  /* ---------- restore ---------- */

  function askRestore(name, version, currentVersion) {
    state.pendingRestore = { name, version: version.version };
    $('#restoreText').textContent =
      `Version ${version.version} of "${name}" will be copied into a new version ${currentVersion + 1}. ` +
      'Nothing is deleted, so you can switch back at any time.';
    $('#restoreDialog').showModal();
  }

  async function confirmRestore() {
    const pending = state.pendingRestore;
    $('#restoreDialog').close();
    if (!pending) return;
    try {
      const result = await api(fileUrl(pending.name, '/restore'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ version: pending.version }),
      });
      toast(result.message);
      await refresh();
    } catch (err) {
      toast(err.message, true);
    } finally {
      state.pendingRestore = null;
    }
  }

  /* ---------- upload ---------- */

  function uploadOne(file, note, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('PUT', fileUrl(file.name));
      xhr.setRequestHeader('Content-Type', 'application/octet-stream');
      if (note) xhr.setRequestHeader('X-Version-Note', encodeURIComponent(note));
      xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(e.loaded / e.total); };
      xhr.onload = () => {
        let body = {};
        try { body = JSON.parse(xhr.responseText); } catch { /* ignore */ }
        if (xhr.status >= 200 && xhr.status < 300) resolve(body);
        else reject(new Error(body.error || `Upload failed (${xhr.status}).`));
      };
      xhr.onerror = () => reject(new Error('Network error. Is the server still running?'));
      xhr.send(file);
    });
  }

  async function uploadFiles(fileList) {
    const files = Array.from(fileList);
    if (!files.length) return;
    const note = $('#noteInput').value.trim();
    const progress = $('#progress');
    const bar = $('#progressBar');
    const hint = $('#dzHint');
    let lastName = null;

    for (const [index, file] of files.entries()) {
      const nameProblem = checkName(file.name);
      if (nameProblem) { toast(`${file.name}: ${nameProblem}`, true); continue; }
      if (file.size > state.maxUploadBytes) {
        toast(`${file.name} is larger than the ${formatBytes(state.maxUploadBytes)} limit.`, true);
        continue;
      }
      progress.hidden = false;
      hint.textContent = `Uploading ${file.name} (${index + 1} of ${files.length})…`;
      bar.style.width = '0%';
      try {
        const result = await uploadOne(file, note, (fraction) => { bar.style.width = `${Math.round(fraction * 100)}%`; });
        toast(result.message);
        lastName = file.name;
      } catch (err) {
        toast(`${file.name}: ${err.message}`, true);
      }
    }
    progress.hidden = true;
    hint.textContent = 'Uploading a name that already exists adds a new version.';
    $('#fileInput').value = '';
    if (lastName) state.selected = lastName;
    await refresh();
  }

  /* ---------- wiring ---------- */

  function init() {
    const dropzone = $('#dropzone');
    $('#fileInput').addEventListener('change', (e) => uploadFiles(e.target.files));
    for (const type of ['dragenter', 'dragover']) {
      dropzone.addEventListener(type, (e) => { e.preventDefault(); dropzone.classList.add('is-over'); });
    }
    for (const type of ['dragleave', 'drop']) {
      dropzone.addEventListener(type, (e) => { e.preventDefault(); dropzone.classList.remove('is-over'); });
    }
    dropzone.addEventListener('drop', (e) => uploadFiles(e.dataTransfer.files));
    $('#filter').addEventListener('input', (e) => { state.filter = e.target.value; renderFiles(); });
    $('#restoreConfirm').addEventListener('click', confirmRestore);
    $('#restoreCancel').addEventListener('click', () => { state.pendingRestore = null; $('#restoreDialog').close(); });

    api('/api/config').then((cfg) => { state.maxUploadBytes = cfg.maxUploadBytes; }).catch(() => {});
    refresh().catch((err) => toast(err.message, true));
  }

  init();
})();
