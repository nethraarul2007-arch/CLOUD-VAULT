# CloudVault: Secure File Storage and Version Recovery System

CloudVault stores files on your own computer, keeps **every version** of each file, and lets you **restore any earlier version** with one click. It is built with plain HTML, CSS, JavaScript and **Node.js built-in modules only**. There is nothing to install and no `node_modules` folder.

![Architecture](docs/architecture.svg)

## Features

- Upload one or many files (drag and drop or file picker) with a progress bar
- Download the current version or any older version
- File list with version number, size, last-updated time and a filter box
- Version history timeline with notes, size, date and SHA-256 fingerprint
- One-click restore: copies an old version into a **new** version, so history is never lost
- Safe filename validation on both the browser and the server
- Duplicate detection: uploading identical content does not create a new version
- Integrity check: a version whose stored bytes no longer match its fingerprint is refused on restore

## Requirements

- Node.js 18 or newer (check with `node -v`). Download from https://nodejs.org if needed.
- A modern browser (Chrome, Edge, Firefox, Safari).

## Run it in VS Code

1. Extract the ZIP. You get a folder called `cloudvault`.
2. In VS Code choose **File > Open Folder...** and select `cloudvault`.
3. Open a terminal with **Terminal > New Terminal** and run:

```bash
npm start
```

4. Open **http://localhost:3000** in your browser.
5. Stop the server with `Ctrl + C` in the terminal.

You can also press **F5** in VS Code and pick "Run CloudVault" (see `.vscode/launch.json`).

## Commands

| Command | What it does |
| --- | --- |
| `npm start` | Starts the server on http://localhost:3000 |
| `npm run dev` | Starts with auto-restart when server files change |
| `npm test` | Runs the 19 automated API tests (uses a temporary folder, never your real data) |
| `node server.js` | Same as `npm start` |

Change the port or limits with environment variables:

```bash
# macOS / Linux
PORT=4000 MAX_UPLOAD_MB=100 npm start

# Windows PowerShell
$env:PORT=4000; $env:MAX_UPLOAD_MB=100; npm start

# Windows Command Prompt
set PORT=4000 && npm start
```

| Variable | Default | Meaning |
| --- | --- | --- |
| `PORT` | `3000` | Port to listen on |
| `HOST` | `127.0.0.1` | Address to bind. The default means only this computer can connect |
| `MAX_UPLOAD_MB` | `50` | Largest allowed upload |
| `MAX_VERSIONS` | `25` | Versions kept per file; the oldest are pruned beyond this |
| `CLOUDVAULT_STORAGE` | `./storage` | Where files are stored |

## Folder structure

```
cloudvault/
├── package.json            Scripts and metadata (no dependencies)
├── server.js               HTTP server, router, security headers, static files
├── lib/
│   ├── config.js           Settings and environment variables
│   ├── errors.js           HttpError (status code + message)
│   ├── validate.js         Filename, version and note validation
│   └── storage.js          Versioned local storage engine
├── public/
│   ├── index.html          Page structure
│   ├── styles.css          Styling
│   └── app.js              Browser logic (upload, list, history, restore)
├── tests/
│   └── api.test.js         Automated tests (node:test)
├── storage/                Created data lives here (git-ignored)
│   ├── objects/<key>/      meta.json, v1.bin, v2.bin ...
│   └── tmp/                Uploads in progress
├── docs/
│   ├── architecture.svg    Architecture diagram
│   ├── ARCHITECTURE.md     Local storage design and flows
│   ├── CLOUD_INTEGRATION.md  Optional cloud storage design
│   ├── PROJECT_REPORT.md   Full project report
│   └── VIVA_QUESTIONS.md   Viva questions with answers
└── .vscode/launch.json     F5 run and test configurations
```

## REST API

| Method and path | Purpose |
| --- | --- |
| `GET /api/files` | List files and storage totals |
| `PUT /api/files/:name` | Upload the request body as a new file or a new version. Optional header `X-Version-Note` (URL-encoded) |
| `GET /api/files/:name` | Download the current version |
| `GET /api/files/:name?version=N` | Download version N |
| `GET /api/files/:name/versions` | Version history, newest first |
| `POST /api/files/:name/restore` | Body `{"version": N}`. Copies version N into a new version |
| `GET /api/config` | Upload limit and version limit |
| `GET /api/health` | Liveness check |

Try it from a terminal while the server runs:

```bash
curl -X PUT --data-binary @report.txt http://localhost:3000/api/files/report.txt
curl http://localhost:3000/api/files/report.txt/versions
curl -X POST -H "Content-Type: application/json" -d '{"version":1}' \
     http://localhost:3000/api/files/report.txt/restore
curl -OJ "http://localhost:3000/api/files/report.txt?version=1"
```

## File name rules

A name is accepted only if it:

- is 1 to 120 characters, with no leading or trailing space
- contains none of `\ / : * ? " < > |` or control characters
- does not start or end with a dot and does not contain `..`
- is not a Windows device name (`CON`, `NUL`, `COM1`, `LPT1`, ...)
- does not end in `.exe .bat .cmd .com .scr .msi .dll .vbs .ps1`

## Security summary

- Files are stored under a hash of their name, so user text is never part of a disk path
- Downloads are always `application/octet-stream` with `Content-Disposition: attachment` and `nosniff`
- Uploads are streamed to a temp file, size-limited, hashed, then renamed into place
- The server listens on `127.0.0.1` only, checks the `Host` header (DNS rebinding) and the `Origin` header (cross-site requests)
- Content Security Policy blocks inline scripts; the UI builds its DOM with `textContent`, never `innerHTML`

CloudVault has **no login**. It is designed for one user on one computer. Do not expose it to a network without adding authentication and HTTPS (see `docs/CLOUD_INTEGRATION.md`).

## Troubleshooting

| Problem | Fix |
| --- | --- |
| `Port 3000 is already in use` | Run with another port, for example `PORT=4000 npm start` |
| `npm` is not recognised | Install Node.js 18+ and reopen the terminal |
| Upload rejected as too large | Raise `MAX_UPLOAD_MB` |
| A file name is refused | Rename it using the rules above |
| Want to reset everything | Stop the server and delete `storage/objects` |

## Further reading

`docs/PROJECT_REPORT.md`, `docs/ARCHITECTURE.md`, `docs/CLOUD_INTEGRATION.md`, `docs/VIVA_QUESTIONS.md`
