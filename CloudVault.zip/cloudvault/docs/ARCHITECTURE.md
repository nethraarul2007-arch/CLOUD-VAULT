# Architecture and Local Storage Design

![Architecture](architecture.svg)

## 1. Layers

| Layer | Files | Responsibility |
| --- | --- | --- |
| Presentation | `public/index.html`, `styles.css`, `app.js` | Page, upload, listing, version timeline, restore dialog |
| HTTP | `server.js` | Routing, security headers, Host/Origin checks, static files, streaming downloads |
| Validation | `lib/validate.js` | Filename, version number and note rules |
| Storage | `lib/storage.js` | Versions, locking, hashing, restore, pruning |
| Persistence | `storage/` on disk | Immutable version files plus one `meta.json` per file |

Dependencies point downward only. `storage.js` knows nothing about HTTP, which is what makes a cloud adapter possible later.

## 2. On-disk layout

```
storage/
├── objects/
│   └── 9f3c...a1/            <- key = first 32 hex chars of SHA-256(file name)
│       ├── meta.json
│       ├── v1.bin
│       ├── v2.bin
│       └── v3.bin
└── tmp/                      <- staging area for uploads in progress
```

`meta.json` example:

```json
{
  "name": "report.pdf",
  "createdAt": "2026-10-22T09:41:36.051Z",
  "versions": [
    { "version": 1, "size": 1200, "sha256": "4f49...", "uploadedAt": "...", "note": "First draft", "restoredFrom": null },
    { "version": 2, "size": 1530, "sha256": "a81c...", "uploadedAt": "...", "note": "", "restoredFrom": null },
    { "version": 3, "size": 1200, "sha256": "4f49...", "uploadedAt": "...", "note": "Restored from v1", "restoredFrom": 1 }
  ]
}
```

### Why these choices

- **Hashed directory names.** The original name is stored only inside `meta.json`. Path traversal, reserved names, case-insensitive file systems and very long names cannot affect the disk layout.
- **Immutable version files.** `v2.bin` is written once and never modified. Restore adds `v3.bin`; it does not overwrite anything.
- **Metadata separate from content.** Listing files reads small JSON files, not the content.
- **SHA-256 per version.** Used for duplicate detection, integrity checking and as an ETag.

## 3. Upload flow (`PUT /api/files/:name`)

1. Router decodes the name and calls `validateFilename`. Failure returns 400.
2. `Origin` is checked. Declared `Content-Length` above the limit returns 413 immediately.
3. The request body is streamed through a meter that counts bytes, enforces the limit and feeds a SHA-256 hash, into `storage/tmp/<uuid>.part`. Memory use stays flat for large files.
4. The per-file lock is taken (see section 5).
5. If the hash equals the current version's hash, the temp file is discarded and the response is `200 created:false`.
6. Otherwise the temp file is **renamed** to `v<N+1>.bin` (atomic on one file system), the version is appended to `meta.json`, which is itself written via temp file and rename, and old versions beyond `MAX_VERSIONS` are pruned.
7. Response `201` with the new version record.

A crash at any step leaves either the old state or the new state, never a half-written version. Leftover `tmp/` files are deleted at start-up.

## 4. Restore flow (`POST /api/files/:name/restore`)

1. Take the per-file lock and load `meta.json`.
2. Reject if the chosen version is missing (404) or has the same content as the current version (409).
3. Re-hash `v<N>.bin` and compare with the recorded SHA-256. A mismatch returns 409 and nothing is changed.
4. Copy to `tmp/`, rename to `v<latest+1>.bin`, append a record with `restoredFrom: N` and the note "Restored from vN".

Because restore creates a new version, you can undo a restore by restoring the version you were on before.

## 5. Concurrency

Node runs JavaScript on one thread, but file operations are asynchronous, so two uploads of the same file could interleave and pick the same version number. `withLock(key, fn)` chains promises per file key so each file's commit section runs one at a time. Different files do not block each other. The test "concurrent uploads get unique, gapless version numbers" sends six simultaneous uploads and checks for versions 1 to 6.

## 6. Download flow

`GET /api/files/:name[?version=N]` resolves the version, `stat`s the file and streams it with `pipeline`. Headers: `Content-Type: application/octet-stream`, `Content-Disposition: attachment` (ASCII fallback plus RFC 5987 UTF-8 name), `X-Content-Type-Options: nosniff`, `ETag` and `X-Content-SHA256`. Older versions download as `name (vN).ext`.

## 7. Security controls

| Threat | Control |
| --- | --- |
| Path traversal (`../`) | Strict name validation, plus hashed directory names, plus normalised-path check for static files |
| Stored XSS via file content | Always `octet-stream` + `attachment` + `nosniff`; CSP |
| Stored XSS via names or notes | UI uses `textContent`, never `innerHTML` |
| Oversized uploads | Content-Length check and streaming byte limit (413) |
| Cross-site request forgery | `Origin` must match `Host` for PUT and POST |
| DNS rebinding | `Host` must be localhost / 127.0.0.1 when bound to loopback |
| Corrupted storage | SHA-256 verified before restore |
| Partial writes | Temp file + atomic rename |
| Disk exhaustion | `MAX_UPLOAD_MB`, `MAX_VERSIONS` pruning |

## 8. Mermaid version of the diagram

```mermaid
flowchart LR
  B[Browser<br/>index.html, styles.css, app.js] -- HTTP --> S[server.js<br/>router + security headers]
  S --> V[lib/validate.js]
  S --> ST[lib/storage.js]
  ST -- fs --> D[(storage/objects/key/<br/>meta.json, v1.bin, v2.bin)]
  ST -. optional adapter .-> C[(S3 / Azure Blob / GCS)]
```
