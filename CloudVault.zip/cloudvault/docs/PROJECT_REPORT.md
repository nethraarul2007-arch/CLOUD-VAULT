# CloudVault: Secure File Storage and Version Recovery System

**Project report**

| | |
| --- | --- |
| Student name | ______________________ |
| Register number | ______________________ |
| Department / College | ______________________ |
| Guide | ______________________ |
| Technologies | HTML5, CSS3, JavaScript (ES2022), Node.js 18+ (built-in modules only) |
| Date | October 2026 |

---

## 1. Abstract

CloudVault is a web-based file storage system that keeps every version of every uploaded file and allows any earlier version to be restored. It consists of a browser interface written in HTML, CSS and JavaScript, and a back end written with Node.js built-in modules (`http`, `fs`, `path`, `crypto`, `stream`) with no third-party packages. Files are stored on the local disk in an immutable, hash-addressed layout. The system validates file names strictly, streams uploads with a size limit, detects duplicate content, verifies integrity with SHA-256 before restoring and serialises concurrent writes. A suite of 19 automated tests covers the API, security rules and failure cases. A design for optional cloud storage is provided.

## 2. Introduction

People overwrite files by mistake, save a bad edit over a good document, or need yesterday's copy of an assignment. Ordinary folders keep only the latest copy. Version-control tools such as Git solve this for source code but are awkward for general documents. Cloud services such as Google Drive and Dropbox offer version history, but the files then live on someone else's servers. CloudVault shows how a small, self-contained, local system can provide the same recovery capability while demonstrating good practice in secure file handling.

## 3. Problem statement

Design and implement a file storage application that (a) accepts uploads and offers downloads, (b) lists stored files, (c) refuses unsafe file names, (d) keeps a history of versions and (e) restores an earlier version without losing any data, using only HTML, CSS, JavaScript and Node.js built-in modules.

## 4. Objectives

1. Upload, list and download files through a browser.
2. Validate file names to prevent path traversal and other filename-based attacks.
3. Store each upload as a new immutable version when its content changed.
4. Display a version history and restore any version non-destructively.
5. Make the system robust against crashes, concurrent writes, oversized uploads and corrupted data.
6. Use no external dependencies so the project runs with `npm start` after extraction.
7. Document the architecture, test the system and describe a cloud extension.

## 5. Scope and limitations

**In scope:** single-user local use, files up to 50 MB (configurable), version history, restore, validation, tests.

**Out of scope (future work):** user accounts and login, HTTPS, encryption at rest, deleting files or versions from the UI, searching file contents, folders, resumable uploads, a real cloud back end.

## 6. Requirements

### 6.1 Functional requirements

| ID | Requirement |
| --- | --- |
| F1 | Upload one or more files, showing progress |
| F2 | List files with current version, size and last modified time |
| F3 | Download the current version or a chosen version |
| F4 | Reject unsafe file names with a clear message |
| F5 | Create a new version when content changes; do nothing when it is identical |
| F6 | Show version history with date, size, note and fingerprint |
| F7 | Restore a chosen version as a new version |
| F8 | Filter the file list by name |

### 6.2 Non-functional requirements

| ID | Requirement | How it is met |
| --- | --- | --- |
| N1 | Security | Validation, hashed paths, attachment-only downloads, CSP, Host/Origin checks |
| N2 | Reliability | Temp file plus atomic rename, start-up cleanup, SHA-256 verification |
| N3 | Performance | Streaming upload and download, constant memory |
| N4 | Portability | Built-in modules only; Windows, macOS, Linux |
| N5 | Usability | Drag and drop, keyboard focus, confirmation before restore, clear errors |
| N6 | Maintainability | Small modules, tests, documentation |

## 7. System design

### 7.1 Architecture

The system has three tiers on one machine: the **browser** (presentation), the **Node.js server** (routing, validation and storage logic) and the **local disk** (persistence). See `architecture.svg` and `ARCHITECTURE.md`.

### 7.2 Modules

| Module | Role |
| --- | --- |
| `server.js` | Creates the HTTP server, routes requests, adds security headers, serves static files, streams downloads |
| `lib/validate.js` | `validateFilename`, `validateVersion`, `sanitizeNote`, header-safe names |
| `lib/storage.js` | `VaultStorage`: list, history, locate, saveUpload, restore, prune, per-file lock |
| `lib/config.js` | Settings from environment variables |
| `lib/errors.js` | `HttpError` carrying a status code |
| `public/app.js` | UI logic; builds DOM safely, uploads with `XMLHttpRequest` for progress |

### 7.3 Data design

Each file has a directory `storage/objects/<key>/` where `<key>` is the first 32 hex characters of the SHA-256 of the file name. It contains `v1.bin`, `v2.bin`, ... and `meta.json`.

| Field in each version record | Meaning |
| --- | --- |
| `version` | Sequence number, starting at 1 and never reused |
| `size` | Bytes |
| `sha256` | Content fingerprint |
| `uploadedAt` | ISO timestamp |
| `note` | Optional text up to 200 characters |
| `restoredFrom` | Source version number if created by a restore, otherwise `null` |

### 7.4 API

| Method and path | Success | Errors |
| --- | --- | --- |
| `GET /api/files` | 200 list and totals | |
| `PUT /api/files/:name` | 201 new version, 200 unchanged | 400 bad name, 403 origin, 413 too large |
| `GET /api/files/:name[?version=N]` | 200 file stream | 400, 404 |
| `GET /api/files/:name/versions` | 200 history | 400, 404 |
| `POST /api/files/:name/restore` | 201 new version | 400, 404, 409 identical or corrupt |

### 7.5 User interface

A single page with a summary strip (files, versions, space used), a drop zone, a version-note field, a filterable file table and a **version timeline** panel. Each timeline entry shows the version number, a "Current" tag, date, size, note and a shortened SHA-256, with Download and Restore buttons. Restore opens a confirmation dialog that explains that a new version will be created and nothing deleted.

## 8. Implementation highlights

1. **Filename validation** (`validateFilename`): normalises to Unicode NFC, then rejects leading or trailing spaces, length over 120, any of `\ / : * ? " < > |`, control characters, leading or trailing dots, `..`, Windows reserved device names and executable extensions. The browser repeats the check for fast feedback; the server is the authority.
2. **Streaming upload with a meter**: a `Transform` stream counts bytes, aborts with 413 past the limit and updates a SHA-256 hash while data flows to `storage/tmp`.
3. **Atomic commit**: `fs.rename` of the temp file to `vN.bin`, then an atomic rewrite of `meta.json`.
4. **Per-file promise-chain lock**: guarantees unique, gapless version numbers under concurrent uploads.
5. **Non-destructive restore**: copies version N to a new version after re-hashing it.
6. **Safe delivery**: `application/octet-stream`, `attachment`, `nosniff`, RFC 5987 filenames.
7. **Safe rendering**: DOM built with `textContent`, so a malicious file name or note appears as text.

## 9. Testing

### 9.1 Method

- `npm test` runs 19 tests with Node's built-in `node:test` and `assert`. Each run starts the real server on a random port with a temporary storage folder.
- A browser-level smoke test loaded the real page in jsdom against a live server: list rendering, history timeline, restore dialog, restore result, filter and HTML-escaping of notes, with no JavaScript errors.
- Manual `curl` run: upload, re-upload, restore, download headers and on-disk layout.

### 9.2 Automated test cases (all passed: 19 of 19)

| # | Test | Verifies |
| --- | --- | --- |
| 1 | Health and config | Endpoints respond |
| 2 | Static assets and security headers | CSP, nosniff |
| 3 | First upload | Version 1 and note stored |
| 4 | Identical re-upload | No new version |
| 5 | Changed upload | Version 2; history newest first |
| 6 | Listing | Counts and byte totals |
| 7 | Downloads | Current and old versions, attachment headers |
| 8 | Restore | New version 3, `restoredFrom`, history intact |
| 9 | Restore errors | 409 identical, 404 missing, 400 invalid |
| 10 | Unsafe names | 13 bad names plus encoded traversal, malformed escape |
| 11 | Unicode names | Correct content and `filename*` header |
| 12 | Static traversal | `/..%2fserver.js` and variants blocked |
| 13 | Size limit | 413 for declared and streamed bodies; no leftovers in `tmp` |
| 14 | Origin / Host | Cross-site write and rebinding refused; same-origin allowed |
| 15 | Routes / methods | 404, 405, bad version query |
| 16 | Concurrency | Six parallel uploads yield versions 1 to 6 |
| 17 | Integrity | Tampered file refused on restore |
| 18 | Pruning | Only the newest versions kept |
| 19 | Persistence | Data survives a server restart |

### 9.3 Defects found

All 19 automated tests passed on the first complete run and the browser smoke test reported no JavaScript errors, so no functional defects had to be fixed in the final code. Two problems occurred only in the build environment (not in the project): a shell that does not expand `{a,b}` folder lists, and a clean-up command that matched its own command line. Both were corrected and demo data was removed from `storage/` before packaging.

## 10. Results

The application runs with `npm start`, performs all required operations through the browser and API, rejects hostile inputs, keeps full history and recovers earlier versions. All automated and smoke tests passed.

## 11. Challenges

- Choosing a safe on-disk layout so that user-controlled names never become paths.
- Avoiding multipart parsing (error-prone without libraries) by uploading the raw file body with the name in the URL.
- Preventing version-number races without a database.
- Keeping security headers strict (CSP) while still having a usable interface.

## 12. Future enhancements

1. Authentication and per-user storage; HTTPS.
2. Delete and trash with retention policy.
3. Encryption at rest with AES-256-GCM.
4. Cloud back end (see `CLOUD_INTEGRATION.md`).
5. Diff view for text files; version labels and pinning.
6. Resumable and chunked uploads for very large files.
7. Deduplicated block storage to save space across versions.

## 13. Conclusion

CloudVault meets every stated requirement using only the standard library of Node.js and the browser. Its central ideas are simple: never trust a file name, never modify a stored version, write atomically, and verify before restoring. These make it small enough to understand fully while still being safe and dependable.

## 14. References

1. Node.js documentation: `http`, `fs`, `path`, `crypto`, `stream`, `test`. https://nodejs.org/docs/latest/api/
2. OWASP, *Unrestricted File Upload* and *Path Traversal*. https://owasp.org
3. RFC 6266, *Use of the Content-Disposition Header Field*; RFC 5987, *Character Set and Language Encoding for HTTP Header Field Parameters*.
4. MDN Web Docs: Content-Security-Policy, XMLHttpRequest, `<dialog>`.
5. Microsoft Docs, *Naming Files, Paths, and Namespaces* (reserved names).
