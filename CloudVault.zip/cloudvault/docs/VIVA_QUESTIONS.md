# Viva Questions and Model Answers

## A. Project basics

**1. What is CloudVault and what problem does it solve?**
A local web application that stores files and keeps every version, so a mistaken overwrite can be undone by restoring an earlier version.

**2. Why did you use only Node.js built-in modules?**
It keeps the project dependency-free (no `npm install`), removes supply-chain risk, and shows understanding of the platform: `http` for the server, `fs` for storage, `crypto` for hashing, `stream` for large files, `path` for safe paths.

**3. Which technologies are used on each side?**
Front end: HTML, CSS, JavaScript. Back end: Node.js `http`, `fs`, `path`, `crypto`, `stream`. Tests: `node:test`.

**4. Is it "cloud" storage?**
No. It stores on the local disk. The name reflects the cloud-style features (versioning, REST API) and the design allows a cloud back end (see `CLOUD_INTEGRATION.md`).

## B. Storage and versioning

**5. How are versions stored?**
Each file has a folder `storage/objects/<key>/` with `v1.bin`, `v2.bin`... and a `meta.json` listing every version's size, SHA-256, time, note and `restoredFrom`.

**6. Why is the folder name a hash of the file name?**
User text never becomes part of a path, so path traversal, reserved names, long names and case-insensitive file systems cannot cause problems. The real name is kept in `meta.json`.

**7. When is a new version created?**
When an upload's SHA-256 differs from the current version's. Identical content returns "No changes" and stores nothing.

**8. How does restore work, and why does it create a new version?**
It verifies the old version's hash, then copies it to `v<latest+1>`. History is append-only, so nothing is lost and a restore can itself be undone.

**9. What happens when there are more than 25 versions?**
`prune` deletes the oldest versions beyond `MAX_VERSIONS`. The newest version is never removed. Version numbers are never reused.

**10. Why separate `meta.json` from content files?**
Listing and history only read small JSON, not file content, and metadata can be replaced atomically.

**11. What is the difference between this and Git?**
Git stores deltas and commits for text and needs commands; CloudVault stores whole files, works for any file type and needs no tooling. It uses more space but is simpler. Block-level deduplication would narrow that gap.

## C. Security

**12. What is path traversal and how do you prevent it?**
Using names like `../../etc/passwd` to reach other folders. Prevention: the name is validated (no slashes, no `..`), and even valid names are hashed into a directory name, so they are never used in a path. Static file serving also normalises the path and checks it stays inside `public/`.

**13. List the filename rules.**
1 to 120 characters; no leading/trailing space; no `\ / : * ? " < > |` or control characters; no leading/trailing dot or `..`; not a Windows device name (CON, NUL, COM1...); no executable extension (.exe, .bat, ...).

**14. Why validate in both the browser and the server?**
Browser checks give instant feedback; the server check is the real defence because anyone can bypass the browser with curl.

**15. Why are downloads sent as `application/octet-stream` with `attachment` and `nosniff`?**
So a stored `.html` or `.svg` file can never run as a page on your origin (stored XSS). The browser must save it instead of rendering it, and `nosniff` stops it guessing a different type.

**16. How do you stop XSS from file names and notes?**
The UI builds elements with `textContent`, never `innerHTML`, and the CSP blocks inline scripts. A name like `<img onerror=...>` is rejected anyway and a note containing HTML is shown as plain text.

**17. What are the Host and Origin checks for?**
Origin check blocks CSRF: another website cannot make your browser upload or restore. Host check blocks DNS rebinding, where a malicious site points its domain at 127.0.0.1.

**18. Why bind to 127.0.0.1?**
There is no login, so the server must only be reachable from the same computer. Exposing it needs authentication and HTTPS first.

**19. How do you handle oversized uploads?**
Early rejection if `Content-Length` is above the limit, and a streaming byte counter that aborts with 413 if the body grows past it. The temp file is deleted.

**20. What does the SHA-256 do in this project?**
Duplicate detection, integrity verification before restore, ETag and a fingerprint shown to the user.

## D. Reliability and concurrency

**21. How do you avoid corrupt files if the server crashes during an upload?**
Data is written to `storage/tmp` first and moved with `rename`, which is atomic on one file system. `meta.json` is also written to a temp file and renamed. On start-up, leftover temp files are removed.

**22. Node is single-threaded, so why is a lock needed?**
File operations are asynchronous, so two requests can interleave between "read meta" and "write meta" and choose the same version number. `withLock` runs a file's commit section one request at a time. Different files are independent.

**23. What happens if a stored version file is modified on disk?**
Restore re-hashes it and compares with `meta.json`; a mismatch returns 409 and nothing changes. (Tested.)

**24. How would this scale to several servers?**
The in-memory lock only protects one process. You would need a shared lock or conditional writes in a database or object store, and shared storage.

## E. HTTP and design choices

**25. Why upload the raw file body with `PUT` instead of `multipart/form-data`?**
Multipart parsing is complex and easy to get wrong without a library. A raw body can be streamed straight to disk, and the file name is carried in the URL where it is validated first.

**26. Why `XMLHttpRequest` for upload but `fetch` elsewhere?**
`fetch` cannot report upload progress; XHR can.

**27. What do the status codes 200, 201, 400, 403, 404, 405, 409, 413 mean here?**
200 OK or unchanged upload; 201 new version created; 400 invalid input; 403 forbidden origin/host; 404 not found; 405 method not allowed; 409 conflict (restoring identical or corrupt version); 413 file too large.

**28. Why `Content-Disposition` with both `filename` and `filename*`?**
`filename` is an ASCII fallback; `filename*` carries the real UTF-8 name encoded per RFC 5987, so names like "résumé.txt" download correctly.

**29. What is idempotency here?**
Uploading the same content twice is harmless: the second call changes nothing.

## F. Testing

**30. How was the system tested?**
19 automated API tests with `node:test` (functional, security, failure and concurrency cases), a browser smoke test with jsdom, and a manual curl run. All passed.

**31. Name some security tests.**
Encoded traversal in names, static traversal URLs, cross-origin PUT, bad Host, oversized bodies, tampered version file.

**32. How would you test the UI automatically?**
Use Playwright or Cypress to drive a real browser: upload, check the timeline, click Restore, assert the new version.

## G. Cloud and future work

**33. How would you add cloud storage?**
Put an adapter with the same methods as `VaultStorage` in front of S3, Azure Blob or GCS: versions become `v<N>` object keys, `meta.json` becomes an object or database item, hashes use the provider's checksum, and pruning uses lifecycle rules. Add authentication, HTTPS, encryption and least-privilege credentials.

**34. What are pre-signed URLs?**
Time-limited URLs that let the browser upload or download directly to or from the bucket, so large files do not pass through the Node server.

**35. What features would you add next?**
Login and per-user storage, delete with trash, encryption at rest (AES-256-GCM), diff view for text, resumable uploads and block-level deduplication.

**36. What are the project's limitations?**
Single user, no authentication, whole-file storage (space grows with each version), 50 MB default limit, no delete in the UI.

## H. Quick one-liners

- *What does `fs.rename` guarantee?* Atomic replacement within one file system.
- *What is a stream?* Data processed in chunks, so memory use does not grow with file size.
- *What is CSP?* A header telling the browser which sources of scripts and styles are allowed.
- *What is a SHA-256 hash?* A 256-bit fingerprint; any change in the input changes it completely.
- *Why never reuse version numbers?* So a number always refers to one specific content, even after pruning.
