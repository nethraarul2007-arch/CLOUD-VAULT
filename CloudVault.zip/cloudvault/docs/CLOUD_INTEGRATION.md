# Optional Cloud Integration (design, not implemented)

The delivered project is **local only**, and that is deliberate: Node.js has no built-in client for AWS, Azure or Google, and the brief asked for built-in modules only. This document explains how cloud storage would be added without redesigning the application.

## 1. Why it is easy to add

`lib/storage.js` is the only file that touches the disk, and `server.js` only calls these methods:

```
list()                       history(name)
locate(name, version)        saveUpload(name, stream, {note})
restore(name, version)
```

A cloud version replaces what is behind these methods. The HTTP layer, validation and browser code stay the same.

## 2. Three integration patterns

| Pattern | How it works | Good for | Trade-off |
| --- | --- | --- | --- |
| Backup / mirror | Keep local storage as is. After each commit, copy `vN.bin` and `meta.json` to a bucket in the background | Disaster recovery | Cloud is a copy, not the source of truth |
| Cloud as primary | Implement the same methods against a bucket. Local disk is only the temp stage | Multi-device access, large capacity | Network latency, cost |
| Hybrid cache | Cloud is the source of truth, recent versions cached locally | Fast reads, durable storage | Cache invalidation logic |

## 3. Mapping to Amazon S3 (Azure Blob and Google Cloud Storage are equivalent)

| CloudVault concept | S3 equivalent |
| --- | --- |
| `objects/<key>/vN.bin` | Object key `objects/<key>/v<N>` (keep CloudVault's own numbering, so behaviour matches the local version) |
| `meta.json` | Object `objects/<key>/meta.json`, or a DynamoDB item per file for atomic updates |
| `tmp/` staging | S3 multipart upload (large files) or `PutObject` |
| SHA-256 | `x-amz-checksum-sha256` header, verified by S3 on upload |
| Pruning | S3 Lifecycle rule (expire old `v<N>` keys) |
| Per-file lock | Conditional write (`If-None-Match`) or DynamoDB conditional update, because an in-process lock does not work across several servers |

An alternative is S3 **bucket versioning**: S3 itself keeps every overwrite as a `VersionId`. It is less work but ties version numbers to S3 identifiers and makes "restore" a copy of a `VersionId`.

## 4. Sketch of an adapter (illustrative, untested)

```js
// lib/storage-s3.js: same public methods as VaultStorage
const { S3Client, PutObjectCommand, GetObjectCommand, CopyObjectCommand } = require('@aws-sdk/client-s3'); // external package

class S3Storage {
  constructor({ bucket, region }) { this.bucket = bucket; this.s3 = new S3Client({ region }); }

  async saveUpload(name, readable, { note }) {
    // 1. stage to a temp file while hashing (same meter as the local engine)
    // 2. read meta.json from S3; compare hashes; choose next version number
    // 3. PutObject objects/<key>/v<N> with ChecksumSHA256 and ServerSideEncryption: 'aws:kms'
    // 4. write meta.json with a conditional write so two servers cannot both claim v<N>
  }

  async restore(name, version) {
    // CopyObject v<version> -> v<latest+1>; append metadata record with restoredFrom
  }

  async locate(name, version) {
    // return a stream from GetObject, or a short-lived pre-signed URL
  }
}
```

Because the AWS SDK is an external package, using it means running `npm install`. That is the point where the "built-in modules only" rule would be relaxed. It is also possible with only built-in `https` and `crypto` by signing requests with AWS Signature V4 yourself, but that is long and error-prone for a student project.

## 5. What must change for the cloud

1. **Authentication.** Add login (sessions or JWT) and per-user key prefixes such as `users/<id>/objects/...`. The local version assumes a single trusted user on `127.0.0.1`.
2. **HTTPS.** Required for any network exposure (reverse proxy such as Nginx or a cloud load balancer).
3. **Encryption.** TLS in transit, server-side encryption at rest (SSE-S3 or SSE-KMS). For stronger privacy, encrypt in the server with `crypto.createCipheriv('aes-256-gcm', ...)` before upload (client-side encryption) and keep the key in a secrets manager.
4. **Least-privilege credentials.** IAM role allowed only `s3:GetObject`, `s3:PutObject`, `s3:ListBucket` on this one bucket. Never put credentials in the browser or in git.
5. **Direct transfers.** Return pre-signed URLs so large files go browser to bucket and do not pass through Node.
6. **Locking across servers.** Conditional writes or a database; the in-memory `withLock` only protects a single process.
7. **Cost controls.** Lifecycle rules, `MAX_VERSIONS`, storage class transitions for old versions.
8. **Monitoring.** Access logs, CloudTrail or equivalent, alerts on failed integrity checks.

## 6. Recommended path for a follow-up project

1. Extract an interface and make `VaultStorage` one implementation.
2. Add a `STORAGE_BACKEND=local|s3` setting.
3. Implement the mirror pattern first (lowest risk), then optionally cloud-primary.
4. Add authentication before anything is reachable from outside the computer.
