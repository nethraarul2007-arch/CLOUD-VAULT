'use strict';
const http = require('node:http');
const fs = require('node:fs');
const fsp = fs.promises;
const path = require('node:path');
const { pipeline } = require('node:stream');
const config = require('./lib/config');
const { VaultStorage } = require('./lib/storage');
const { HttpError } = require('./lib/errors');
const {
  validateFilename, validateVersion, sanitizeNote, asciiFallback, versionedName,
} = require('./lib/validate');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
};

function sendJson(res, status, body, extraHeaders = {}) {
  const payload = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': payload.length,
    ...extraHeaders,
  });
  res.end(payload);
}

function safeDecode(segment) {
  try {
    return decodeURIComponent(segment);
  } catch {
    throw new HttpError(400, 'Malformed URL encoding.');
  }
}

function rfc5987(text) {
  return encodeURIComponent(text).replace(/['()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
}

function readJsonBody(req, limit = 2048) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new HttpError(413, 'Request body is too large.'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
        if (parsed === null || typeof parsed !== 'object') throw new Error('not an object');
        resolve(parsed);
      } catch {
        reject(new HttpError(400, 'Request body must be valid JSON.'));
      }
    });
    req.on('error', reject);
  });
}

function createServer(options = {}) {
  const opts = { ...config, ...options };
  const storage = new VaultStorage({
    dir: opts.STORAGE_DIR,
    maxUploadBytes: opts.MAX_UPLOAD_BYTES,
    maxVersions: opts.MAX_VERSIONS,
  });
  const loopbackOnly = ['127.0.0.1', 'localhost', '::1'].includes(opts.HOST);

  function setSecurityHeaders(res) {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader(
      'Content-Security-Policy',
      "default-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'; base-uri 'none'"
    );
  }

  /** Blocks DNS-rebinding when the server is only meant for this computer. */
  function checkHost(req) {
    if (!loopbackOnly) return;
    const host = (req.headers.host || '').replace(/:\d+$/, '').toLowerCase();
    if (!['localhost', '127.0.0.1', '[::1]'].includes(host)) {
      throw new HttpError(403, 'Host header not allowed.');
    }
  }

  /** Blocks cross-site requests that try to change data (CSRF). */
  function checkOrigin(req) {
    const origin = req.headers.origin;
    if (!origin) return;
    let sameOrigin = false;
    try { sameOrigin = new URL(origin).host === req.headers.host; } catch { /* invalid origin */ }
    if (!sameOrigin) throw new HttpError(403, 'Cross-origin requests are not allowed.');
  }

  async function serveStatic(req, res, pathname) {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.setHeader('Allow', 'GET, HEAD');
      throw new HttpError(405, 'Method not allowed.');
    }
    const decoded = safeDecode(pathname === '/' ? '/index.html' : pathname);
    if (decoded.includes('\0')) throw new HttpError(400, 'Bad path.');
    const filePath = path.normalize(path.join(opts.PUBLIC_DIR, decoded));
    if (!filePath.startsWith(opts.PUBLIC_DIR + path.sep)) throw new HttpError(403, 'Forbidden.');
    let stat;
    try { stat = await fsp.stat(filePath); } catch { throw new HttpError(404, 'Not found.'); }
    if (!stat.isFile()) throw new HttpError(404, 'Not found.');
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream',
      'Content-Length': stat.size,
      'Cache-Control': 'no-cache',
    });
    if (req.method === 'HEAD') return res.end();
    pipeline(fs.createReadStream(filePath), res, (err) => { if (err) res.destroy(); });
  }

  async function upload(req, res, name) {
    const declared = Number(req.headers['content-length']);
    if (Number.isFinite(declared) && declared > opts.MAX_UPLOAD_BYTES) {
      throw new HttpError(413, `File is larger than the ${Math.round(opts.MAX_UPLOAD_BYTES / 1048576)} MB limit.`);
    }
    let note = '';
    try { note = decodeURIComponent(req.headers['x-version-note'] || ''); } catch { /* ignore bad note */ }
    const result = await storage.saveUpload(name, req, { note: sanitizeNote(note) });
    sendJson(res, result.created ? 201 : 200, {
      created: result.created,
      message: result.created
        ? `Saved "${name}" as version ${result.version.version}.`
        : `No changes: "${name}" is identical to version ${result.version.version}.`,
      file: result.file,
      version: result.version,
    });
  }

  async function download(req, res, name, query) {
    const wanted = query.has('version') ? validateVersion(query.get('version')) : undefined;
    const { info, isCurrent, filePath } = await storage.locate(name, wanted);
    let stat;
    try { stat = await fsp.stat(filePath); } catch {
      throw new HttpError(409, 'Stored data for this version is missing.');
    }
    const filename = isCurrent ? name : versionedName(name, info.version);
    res.writeHead(200, {
      'Content-Type': 'application/octet-stream', // never let the browser render user content
      'Content-Length': stat.size,
      'Content-Disposition': `attachment; filename="${asciiFallback(filename)}"; filename*=UTF-8''${rfc5987(filename)}`,
      'X-Content-SHA256': info.sha256,
      'X-CloudVault-Version': String(info.version),
      ETag: `"${info.sha256}"`,
    });
    if (req.method === 'HEAD') return res.end();
    pipeline(fs.createReadStream(filePath), res, (err) => { if (err) res.destroy(); });
  }

  function methodNotAllowed(res, allow) {
    res.setHeader('Allow', allow);
    throw new HttpError(405, 'Method not allowed.');
  }

  async function api(req, res, segments, query) {
    res.setHeader('Cache-Control', 'no-store');
    const method = req.method;
    if (method === 'PUT' || method === 'POST') checkOrigin(req);

    const [, resource, rawName, sub, extra] = segments;
    if (extra !== undefined) throw new HttpError(404, 'Unknown API route.');

    if (resource === 'health' && rawName === undefined) {
      if (method !== 'GET') methodNotAllowed(res, 'GET');
      return sendJson(res, 200, { status: 'ok' });
    }
    if (resource === 'config' && rawName === undefined) {
      if (method !== 'GET') methodNotAllowed(res, 'GET');
      return sendJson(res, 200, { maxUploadBytes: opts.MAX_UPLOAD_BYTES, maxVersions: opts.MAX_VERSIONS });
    }
    if (resource !== 'files') throw new HttpError(404, 'Unknown API route.');

    if (rawName === undefined) {
      if (method !== 'GET') methodNotAllowed(res, 'GET');
      return sendJson(res, 200, await storage.list());
    }

    const name = validateFilename(rawName);

    if (sub === undefined) {
      if (method === 'PUT') return upload(req, res, name);
      if (method === 'GET' || method === 'HEAD') return download(req, res, name, query);
      return methodNotAllowed(res, 'GET, HEAD, PUT');
    }
    if (sub === 'versions') {
      if (method !== 'GET') methodNotAllowed(res, 'GET');
      return sendJson(res, 200, await storage.history(name));
    }
    if (sub === 'restore') {
      if (method !== 'POST') methodNotAllowed(res, 'POST');
      const body = await readJsonBody(req);
      if (body.version === undefined) throw new HttpError(400, 'Body must include "version".');
      const version = validateVersion(body.version);
      const result = await storage.restore(name, version);
      return sendJson(res, 201, {
        message: `Restored version ${version} of "${name}" as version ${result.version.version}.`,
        file: result.file,
        version: result.version,
      });
    }
    throw new HttpError(404, 'Unknown API route.');
  }

  async function handle(req, res) {
    setSecurityHeaders(res);
    await storage.ready;
    checkHost(req);
    if (!req.url.startsWith('/')) throw new HttpError(400, 'Bad request target.');
    const qIndex = req.url.indexOf('?');
    const rawPath = qIndex === -1 ? req.url : req.url.slice(0, qIndex);
    const query = new URLSearchParams(qIndex === -1 ? '' : req.url.slice(qIndex + 1));
    const segments = rawPath.split('/').filter(Boolean);
    if (segments[0] === 'api') {
      return api(req, res, segments.map(safeDecode), query);
    }
    return serveStatic(req, res, rawPath);
  }

  function fail(res, err) {
    if (res.headersSent) return res.destroy();
    if (err instanceof HttpError) {
      return sendJson(res, err.status, { error: err.message }, err.status === 413 ? { Connection: 'close' } : {});
    }
    if (err && (err.code === 'ERR_STREAM_PREMATURE_CLOSE' || err.code === 'ECONNRESET')) {
      return res.destroy(); // client went away mid-upload
    }
    console.error(err);
    return sendJson(res, 500, { error: 'Internal server error.' });
  }

  const server = http.createServer((req, res) => {
    handle(req, res).catch((err) => fail(res, err));
  });
  server.storage = storage;
  return server;
}

if (require.main === module) {
  const server = createServer();
  server.on('error', (err) => {
    console.error(err.code === 'EADDRINUSE'
      ? `Port ${config.PORT} is already in use. Try: PORT=4000 npm start`
      : err.message);
    process.exit(1);
  });
  server.storage.ready
    .then(() => server.listen(config.PORT, config.HOST, () => {
      console.log(`CloudVault is running at http://${config.HOST === '127.0.0.1' ? 'localhost' : config.HOST}:${config.PORT}`);
      console.log(`Storage folder: ${config.STORAGE_DIR}`);
    }))
    .catch((err) => { console.error(`Cannot prepare storage: ${err.message}`); process.exit(1); });
  process.on('SIGINT', () => server.close(() => process.exit(0)));
}

module.exports = { createServer };
